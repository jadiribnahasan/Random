/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author user
 */
import java.util.Queue;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Producer implements Runnable{

    Semaphore mutex = null;
    Semaphore empty = null;
    Semaphore full = null;
    Queue<Integer> buffer=null;
    Random rand = new Random();
    
    Producer(Semaphore mutex,Semaphore empty,Semaphore full,Queue<Integer> buffer){
        this.mutex=mutex;
        this.empty=empty;
        this.full=full;
        this.buffer=buffer;
    } 

    private int produce(){
        int n = rand.nextInt(1000);
        return n;
    }
    
    @Override
    public void run() {
        int item;
        while(true){
            try {
                mutex.down();
                empty.down();
            	item = produce();
                buffer.add(item);
                System.out.println("Added by " + Thread.currentThread().getName() + " : " + item);
                mutex.up();
                full.up();
                Thread.sleep(rand.nextInt(30) + 1);
            } catch (InterruptedException ex) {
                Logger.getLogger(Producer.class.getName()).log(Level.SEVERE, null, ex);
            }
                      
        }
               
    }
    
        
}
