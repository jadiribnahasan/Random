/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author user
 */
import java.util.LinkedList;
import java.util.Queue;

public class ProducerConsumer {

    /**
     * @param args the command line arguments
     */
        static int N =5;
        public static Semaphore mutex =new Semaphore(1,1);
        public static Semaphore empty =new Semaphore(N,N);
        public static Semaphore full =new Semaphore(0,N);
        public static Queue<Integer> buffer = new LinkedList<Integer>();
    
    
    public static void main(String[] args) {
       
             
        
        Producer producer1 = new Producer(mutex,empty,full,buffer);
        Producer producer2 = new Producer(mutex,empty,full,buffer);
        Producer producer3 = new Producer(mutex,empty,full,buffer);
        Producer producer4 = new Producer(mutex,empty,full,buffer);
        Producer producer5 = new Producer(mutex,empty,full,buffer);
        Producer producer6 = new Producer(mutex,empty,full,buffer);
        Producer producer7 = new Producer(mutex,empty,full,buffer);
        Producer producer8 = new Producer(mutex,empty,full,buffer);
        
        Consumer consumer1 = new Consumer(mutex,empty,full,buffer);
        Consumer consumer2 = new Consumer(mutex,empty,full,buffer);
        Consumer consumer3 = new Consumer(mutex,empty,full,buffer);
        Consumer consumer4 = new Consumer(mutex,empty,full,buffer);
        Consumer consumer5 = new Consumer(mutex,empty,full,buffer);
        Consumer consumer6 = new Consumer(mutex,empty,full,buffer);
        Consumer consumer7 = new Consumer(mutex,empty,full,buffer);
        Consumer consumer8 = new Consumer(mutex,empty,full,buffer);
        // add more objects
        
        new Thread(producer1,"Producer 1").start();
        
        new Thread(consumer1,"Consumer 1").start();
        
        new Thread(producer2,"Producer 2").start();
               
        new Thread(consumer2,"Consumer 2").start();
        
        new Thread(producer3,"Producer 3").start();
        
        new Thread(consumer3,"Consumer 3").start();
        
        new Thread(producer4,"Producer 4").start();
        
        new Thread(consumer4,"Consumer 4").start();
        
        new Thread(producer5,"Producer 5").start();
        
        new Thread(consumer5,"Consumer 5").start();
        
        new Thread(producer6,"Producer 6").start();
        
        new Thread(consumer6,"Consumer 6").start();
        
        new Thread(producer7,"Producer 7").start();
        
        new Thread(consumer7,"Consumer 7").start();
        
        new Thread(producer8,"Producer 8").start();
        
        new Thread(consumer8,"Consumer 8").start();
        
        //add more threads
        
             
        
    }
    
}
