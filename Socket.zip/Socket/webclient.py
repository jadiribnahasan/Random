from socket import *
import sys

host = sys.argv[1]
port = int(sys.argv[2])
print(type(host), type(port))

s = socket(AF_INET, SOCK_STREAM)
s.connect((host, port))
request = "GET /demo.txt HTTP/1.1\r\n\r\n\r\n"
s.send(request.encode())

status = s.recv(4096)
response = s.recv(4096).decode('utf-8')
print(status, response)

