from socket import *

host = "127.0.0.1"
port = 4446

serverSocket = socket(AF_INET, SOCK_STREAM)
serverSocket.bind((host, port))

serverSocket.listen(1)
print("Waiting for connect")

while True:
    q , addr = serverSocket.accept()
    print("Connected with "+addr[0] + ':' + str(addr[1]))
    
    try:
        msg = q.recv(2048)
        #print(msg)
        filename = msg.split()[1]
        f = open(filename[1:])
        #print(filename)
        output = f.read()
        header = "HTTP/1.1 200 OK\r\n\r\n"
        q.send(header.encode('utf-8'))
        q.send(output.encode('utf-8'))
        #n = "\r\n"
        #q.send(n.encode('utf-8'))
        q.close()
    except IOError:
        error = "HTTP/1.1 404 Not Found\r\n\r\n"
        q.send(error.encode('utf-8'))
        errormsg = "<html><head></head><body><h1>406 Not Found</h1></body></html>\r\n"
        q.send(errormsg.encode('utf-8'))
serverSocket.close()
    
